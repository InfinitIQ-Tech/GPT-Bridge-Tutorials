//
//  GPTBridge_Streaming_FinalApp.swift
//  GPTBridge Streaming Final
//
//  Created by Kenneth Dubroff on 2/19/25.
//

import SwiftUI

@main
struct GPTBridge_Streaming_FinalApp: App {
    var body: some Scene {
        WindowGroup {
            AssistantListView()
        }
    }
}
