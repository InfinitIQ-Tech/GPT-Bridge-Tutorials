//
//  AssistantChatViewModel.swift
//  GPTBridge Streaming Final
//
//  Created by Kenneth Dubroff on 2/19/25.
//

import GPTBridge
import SwiftUI

class AssistantChatViewModel: ObservableObject {
    @Published var activeAssistant: Assistant
    @Published var messages: [ChatMessage] = []
    @Published var streamingText: String = ""
    @Published var isLoading: Bool = false
    @Published var errors: [OpenAIJSONError] = []
    private var threadId: String? = nil

    init(assistant: Assistant) {
        self.activeAssistant = assistant
    }

    func sendMessageFromUser(_ message: String) async {
        Task { @MainActor in
            isLoading = true
            if threadId == nil {
                try await createThreadAndRun(withUserMessage: message)
            } else {
                try await addMessageToThread(message)
            }
            isLoading = false // fallback
        }
    }

    func appendAssistantMessage(_ text: String) {
        messages.append(ChatMessage(content: text, role: .assistant))
    }

    @MainActor
    private func addMessageToThread(_ message: String, fromRole role: Role = .user) async throws {
        let userMessage = ChatMessage(content: message, role: role)
        self.messages.append(userMessage)
        guard let threadId else { return }
        let stream = try await GPTBridge.addMessageAndStreamThreadRun(
            text: message,
            threadId: threadId,
            assistantId: activeAssistant.id
        )
        try await handleAsyncStream(stream)
    }

    @MainActor
    private func createThreadAndRun(withUserMessage message: String, fromRole role: Role = .user) async throws {
        let userMessage = ChatMessage(content: message, role: role)
        self.messages.append(userMessage) // update the UI
        let thread = Thread(messages: [userMessage]) // create a thread object. If your use-case requires it, you can start the thread with mul0tiple messages.

        let stream = try await GPTBridge.createAndStreamThreadRun(
            assistantId: activeAssistant.id,
            thread: thread
        )
        try await handleAsyncStream(stream)
    }

    private func handleAsyncStream(_ stream: AsyncThrowingStream<RunStatusEvent, any Error>) async throws {
        do {
            for try await event in stream {
                switch event {
                case .threadCreated(let threadId):
                    self.threadId = threadId
                case .messageDelta(let text):
                    Task { @MainActor in
                        isLoading = false
                        self.streamingText += text
                    }
                case .messageCompleted(let message):
                    Task { @MainActor in
                        self.streamingText = ""
                        self.messages.append(message)
                    }
                case .errorOccurred(let error):
                    Task { @MainActor in
                        self.errors.append(error)
                    }
                default:
                    break
                }
            }
        } catch {
            print(error)
        }
    }
}
