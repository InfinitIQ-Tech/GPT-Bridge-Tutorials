//
//  AssistantChatView.swift
//  GPTBridge Streaming Final
//
//  Created by Kenneth Dubroff on 2/19/25.
//

import GPTBridge
import SwiftUI

struct AssistantChatView: View {
    @ObservedObject var viewModel: AssistantChatViewModel
    @State private var userInput: String = ""

    var body: some View {
        VStack {
            Text("Chat with \(viewModel.activeAssistant.name ?? "AI Assistant")")
                .font(.largeTitle)
            ScrollView {
                ForEach(viewModel.messages) { message in
                    MessageBubbleView(message: message)
                }
                if !viewModel.streamingText.isEmpty {
                    let message = ChatMessage(content: viewModel.streamingText, role: .assistant)
                    MessageBubbleView(message: message)
                }
                if viewModel.isLoading {
                    ProgressView() {
                        Text("\(viewModel.activeAssistant.name ?? "The Assistant") is thinking...")
                            .font(.caption)
                    }
                    .progressViewStyle(.circular)
                }
                ForEach(viewModel.errors) { error in
                    let message = ChatMessage(content: error.message, role: .assistant)
                    MessageBubbleView(message: message, error: true)
                }
            }
            .frame(maxHeight: .infinity)
            TextEditor(text: $userInput)
                .frame(height: 250)
                .border(.black)
                .padding()
                .cornerRadius(8)
            Button("Send") {
                Task { @MainActor in
                    await viewModel.sendMessageFromUser(userInput)
                    userInput = ""
                }
            }
        }
    }
}

fileprivate struct MessageBubbleView: View {
    let message: ChatMessage
    var error: Bool

    init(message: ChatMessage, error: Bool = false) {
        self.message = message
        self.error = error
    }

    var body: some View {
        HStack {
            if error {
                VStack(alignment: .leading) {
                    Text(message.content)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.red)
                        .cornerRadius(12)
                }
                Spacer()
            } else if message.role == .assistant {
                // Assistant bubble on the left
                VStack(alignment: .leading) {
                    Text(message.content)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(12)
                }
                Spacer()
            } else if message.role == .user {
                // User bubble on the right
                Spacer()
                VStack(alignment: .trailing) {
                    Text(message.content)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.green)
                        .cornerRadius(12)
                }
            }
        }
    }
}
