//
//  ContentView.swift
//  GPTBridge Streaming Final
//
//  Created by Kenneth Dubroff on 2/19/25.
//

import GPTBridge
import SwiftUI

struct AssistantListView: View {
    @State var assistants: [Assistant] = []

    var body: some View {
        NavigationStack {
            List(assistants, id: \.id) { assistant in
                NavigationLink(assistant.name ?? "Undefined") { AssistantChatView(viewModel: AssistantChatViewModel(assistant: assistant))
                }
                Text(assistant.description ?? "")
                    .font(.footnote)
            }
            .padding()
            .task {
                #warning("Remember to provide *your* API Key")
                GPTBridge.appLaunch(openAIAPIKey: "")

                Task { @MainActor in
                    self.assistants = try await GPTBridge.listAssistants().data
                }
            }
        }
    }
}

#Preview {
    AssistantListView()
}

extension Assistant {
    static let previewAssistant: Assistant = Assistant(id: UUID().uuidString, name: "Preview Agent", description: "Used for previews", model: "gpt-4o", instructions: "You are an assistant used in SwiftUI previews.")
}
