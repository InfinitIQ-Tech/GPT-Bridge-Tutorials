//
//  AssistantChatViewModel.swift
//  GPTBridge Streaming Starter
//
//  Created by Kenneth Dubroff on 2/19/25.
//

import GPTBridge
import SwiftUI

class AssistantChatViewModel: ObservableObject {
    @Published var activeAssistant: Assistant
    @Published var messages: [ChatMessage] = []

    init(assistant: Assistant) {
        self.activeAssistant = assistant
    }

    func sendMessageFromUser(_ message: String) async {
        Task { @MainActor in
            messages.append(ChatMessage(content: message, role: .user))
        }
    }

    func appendAssistantMessage(_ text: String) {
        messages.append(ChatMessage(content: text, role: .assistant))
    }
}
