//
//  ContentView.swift
//  GPTBridge Streaming Starter
//
//  Created by Kenneth Dubroff on 2/19/25.
//

import GPTBridge
import SwiftUI

struct AssistantListView: View {
    @State var assistants: [Assistant] = [
        .previewAssistant
    ]

    var body: some View {
        NavigationStack {
            List(assistants, id: \.id) { assistant in
                NavigationLink(assistant.name ?? "Undefined") { AssistantChatView(viewModel: AssistantChatViewModel(assistant: assistant))
                }
                Text(assistant.description ?? "")
                    .font(.footnote)
            }
            .padding()
            .task {
                // TODO: Use GPTBridge to list your custom assistants
            }
        }
    }
}

#Preview {
    AssistantListView()
}

extension Assistant {
    static let previewAssistant: Assistant = Assistant(id: UUID().uuidString, name: "Preview Agent", description: "Used for previews", model: "gpt-4o", instructions: "You are an assistant used in SwiftUI previews.")
}
