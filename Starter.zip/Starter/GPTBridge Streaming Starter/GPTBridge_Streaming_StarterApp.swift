//
//  GPTBridge_Streaming_StarterApp.swift
//  GPTBridge Streaming Starter
//
//  Created by Kenneth Dubroff on 2/19/25.
//

import SwiftUI

@main
struct GPTBridge_Streaming_StarterApp: App {
    var body: some Scene {
        WindowGroup {
            AssistantListView()
        }
    }
}
