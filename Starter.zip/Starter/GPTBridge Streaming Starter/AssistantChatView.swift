//
//  AssistantChatView.swift
//  GPTBridge Streaming Starter
//
//  Created by Kenneth Dubroff on 2/19/25.
//

import GPTBridge
import SwiftUI

struct AssistantChatView: View {
    @ObservedObject var viewModel: AssistantChatViewModel
    @State private var userInput: String = ""

    var body: some View {
        VStack {
            Text("Chat with \(viewModel.activeAssistant.name ?? "AI Assistant")")
                .font(.largeTitle)
            ScrollView {
                ForEach(viewModel.messages) { message in
                    MessageBubbleView(message: message)
                }
            }
            .frame(maxHeight: .infinity)
            TextEditor(text: $userInput)
                .frame(height: 250)
                .border(.black)
                .padding()
                .cornerRadius(8)
            Button("Send") {
                Task { @MainActor in
                    await viewModel.sendMessageFromUser(userInput)
                    userInput = ""
                }
            }
        }
    }
}

fileprivate struct MessageBubbleView: View {
    let message: ChatMessage

    var body: some View {
        HStack {
            if message.role == .assistant {
                // Assistant bubble on the left
                VStack(alignment: .leading) {
                    Text(message.content)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(12)
                }
                Spacer()
            } else if message.role == .user {
                // User bubble on the right
                Spacer()
                VStack(alignment: .trailing) {
                    Text(message.content)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.green)
                        .cornerRadius(12)
                }
            }
        }
    }
}
